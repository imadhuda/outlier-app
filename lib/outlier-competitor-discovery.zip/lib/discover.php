<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/apify.php';
require_once __DIR__ . '/anthropic.php';
require_once __DIR__ . '/engine.php';

/**
 * Competitor auto-discovery — "I don't know my competitors, find them for me."
 *
 * From a seed profile (the creator's own by default), we read the accounts
 * Instagram itself lists as similar, filter out the creator and anyone they
 * already track, and ask Claude to keep only the ones genuinely in their niche.
 * Suggestions are cheap (one profile scrape); a full competitor scrape only ever
 * runs on the handles the creator ticks afterward.
 */
class Discover {
    const MAX_SUGGEST    = 12;   // how many we present
    const MAX_CANDIDATES = 60;   // hard cap sent to the model

    /** Candidate handles from an instagram-scraper 'details' row (its relatedProfiles). */
    public static function relatedFromProfile(array $row) {
        $out = [];
        foreach (($row['relatedProfiles'] ?? []) as $p) {
            if (!is_array($p)) continue;
            $h = strtolower(trim((string)($p['username'] ?? $p['ownerUsername'] ?? '')));
            if ($h === '' || isset($out[$h])) continue;
            $out[$h] = [
                'handle'   => $h,
                'name'     => trim((string)($p['full_name'] ?? $p['fullName'] ?? '')),
                'verified' => !empty($p['is_verified']) || !empty($p['isVerified']),
            ];
        }
        return array_values($out);
    }

    /** Drop the creator's own handle, anything already tracked, and malformed handles. */
    public static function clean(array $candidates, $ownHandle, array $exclude = []) {
        $own = strtolower((string)$ownHandle);
        $ex  = array_flip(array_map('strtolower', $exclude));
        $seen = []; $out = [];
        foreach ($candidates as $c) {
            $h = strtolower((string)($c['handle'] ?? ''));
            if ($h === '' || $h === $own || isset($ex[$h]) || isset($seen[$h])) continue;
            if (!preg_match('/^[a-z0-9._]{1,40}$/', $h)) continue;
            $seen[$h] = 1; $out[] = $c;
        }
        return $out;
    }

    /** Deterministic fallback when the model is unavailable: score by niche-keyword overlap. */
    public static function keywordRank(array $candidates, $niche, $limit = self::MAX_SUGGEST) {
        $kw = Engine::keywords($niche);
        $scored = [];
        foreach ($candidates as $c) {
            $hayWords = Engine::keywords(($c['handle'] ?? '') . ' ' . ($c['name'] ?? ''));
            $hit = 0;
            foreach ($kw as $k) {
                foreach ($hayWords as $w) {
                    if ($w === $k || strpos($w, $k) !== false || strpos($k, $w) !== false) { $hit++; break; }
                }
            }
            $c['score']  = $hit;
            $c['reason'] = $hit ? 'Handle or name matches your niche' : 'Instagram lists this account as similar to yours';
            $scored[] = $c;
        }
        usort($scored, function ($a, $b) {
            if ($b['score'] !== $a['score']) return $b['score'] <=> $a['score'];
            return ($b['verified'] ? 1 : 0) <=> ($a['verified'] ? 1 : 0);
        });
        return array_slice($scored, 0, $limit);
    }

    /** Ask Claude to keep only in-niche competitors, with a one-line reason each. Falls back to keywordRank. */
    public static function rank($cfg, array $candidates, $niche, $ownHandle, $limit = self::MAX_SUGGEST) {
        $candidates = array_slice($candidates, 0, self::MAX_CANDIDATES);
        if (!$candidates) return [];
        try {
            $claude = new Claude($cfg['anthropic_key'] ?? '', $cfg['anthropic_model'] ?? 'claude-sonnet-4-5-20250929');
            $r = $claude->json(self::rankSystem(), self::rankPrompt($candidates, $niche, $ownHandle, $limit), 1500);
            $picks = $r['data']['competitors'] ?? (isset($r['data'][0]) ? $r['data'] : []);
            $byHandle = [];
            foreach ($candidates as $c) $byHandle[strtolower($c['handle'])] = $c;
            $out = [];
            foreach ((array)$picks as $p) {
                if (!is_array($p)) continue;
                $h = ltrim(strtolower(trim((string)($p['handle'] ?? ''))), '@');
                if (!isset($byHandle[$h]) || isset($out[$h])) continue;
                $c = $byHandle[$h];
                $c['reason'] = trim((string)($p['reason'] ?? '')) ?: 'In your niche';
                $c['score']  = 1;
                $out[$h] = $c;
                if (count($out) >= $limit) break;
            }
            if ($out) return array_values($out);
        } catch (Throwable $e) { /* fall through to keyword ranking */ }
        return self::keywordRank($candidates, $niche, $limit);
    }

    public static function rankSystem() {
        return 'You help a short-form video creator find real competitors. You are given a list of Instagram '
             . 'accounts that Instagram itself suggests are similar to the creator, plus the creator\'s niche. '
             . 'Pick ONLY accounts genuinely in the same niche and plausibly competitors — creators or brands '
             . 'posting similar short-form content to a similar audience. Exclude celebrities, unrelated big '
             . 'brands, generic platform suggestions, and anything off-niche. Five strong matches beat twelve '
             . 'weak ones. Never invent a handle that is not in the list.';
    }

    public static function rankPrompt(array $candidates, $niche, $ownHandle, $limit) {
        $L = [];
        $L[] = 'CREATOR: @' . $ownHandle;
        $L[] = 'NICHE (stay strictly inside this): ' . $niche;
        $L[] = '';
        $L[] = 'CANDIDATE ACCOUNTS:';
        foreach ($candidates as $c) {
            $L[] = '@' . $c['handle'] . ' — ' . ($c['name'] !== '' ? $c['name'] : '(no name)') . (!empty($c['verified']) ? ' — verified' : '');
        }
        $L[] = '';
        $L[] = 'Return JSON {"competitors":[{"handle":"exacthandle","reason":"one short line on why they are a competitor"}]} '
             . 'with at most ' . (int)$limit . ', best first. Only handles from the list above.';
        return implode("\n", $L);
    }

    /** Full run: scrape the seed profile, gather + rank related accounts, store them. Returns the suggestions. */
    public static function run($cfg, array $customer, $seedHandle = null) {
        $own  = strtolower((string)$customer['ig_handle']);
        $seed = strtolower(trim((string)($seedHandle !== null && $seedHandle !== '' ? $seedHandle : $own)));
        $seed = preg_replace('#^https?://(www\.)?instagram\.com/#i', '', $seed);
        $seed = trim(preg_replace('/[?#].*$/', '', $seed), "@/ \t");
        if ($seed === '') throw new RuntimeException('Enter a handle to search from.');
        if (!preg_match('/^[a-z0-9._]{1,40}$/', $seed)) throw new RuntimeException('That does not look like a valid Instagram handle.');

        $existing = json_decode((string)$customer['competitors'], true) ?: [];
        $ap   = new Apify($cfg['apify_token'] ?? '');
        $rows = $ap->runSync(Apify::IG_SCRAPER, Apify::igProfileInput($seed), 60);
        if (!$rows) throw new RuntimeException('Instagram did not return @' . $seed . '. Check the handle and that the account is public.');

        $cands = self::relatedFromProfile($rows[0]);
        if (!$cands) throw new RuntimeException('Instagram did not suggest any similar accounts for @' . $seed . '. Try another seed handle, or add competitors by hand.');

        $cands  = self::clean($cands, $own, array_merge($existing, [$seed]));
        if (!$cands) throw new RuntimeException('The similar accounts were all ones you already track. Try a different seed handle.');
        $ranked = self::rank($cfg, $cands, (string)$customer['niche'], $own);
        self::store((int)$customer['id'], $seed, $ranked);
        return $ranked;
    }

    public static function store($customerId, $seed, array $ranked) {
        q("DELETE FROM competitor_suggestions WHERE customer_id=?", [$customerId]);
        if (!$ranked) return;
        $ins = db()->prepare("INSERT INTO competitor_suggestions (customer_id,handle,name,verified,source,reason,sort)
                              VALUES (?,?,?,?,?,?,?)");
        $i = 0;
        foreach ($ranked as $c) {
            $ins->execute([$customerId, $c['handle'], (string)($c['name'] ?? ''),
                           !empty($c['verified']) ? 1 : 0, 'ig:' . $seed,
                           mb_substr((string)($c['reason'] ?? ''), 0, 290), $i++]);
        }
    }

    public static function suggestions($customerId) {
        return all("SELECT * FROM competitor_suggestions WHERE customer_id=? ORDER BY sort ASC, id ASC", [$customerId]);
    }

    public static function clear($customerId) {
        q("DELETE FROM competitor_suggestions WHERE customer_id=?", [$customerId]);
    }
}
